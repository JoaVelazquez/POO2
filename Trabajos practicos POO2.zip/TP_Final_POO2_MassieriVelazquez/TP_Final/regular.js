/*
    |------------------------------------|
    | TRABAJO PRÁCTICO N° 4: GASOLINERA  |
    | PROGRAMACIÓN ORIENTADA A OBJETOS 2 |
    |------------------------------------|
    | INTEGRANTES: AGUSTÍN MASSIERI      |
    |              JOAQUÍN VELAZQUEZ     |
    |------------------------------------|
    | PROFESOR: JOSE RUSCA               |
    |------------------------------------|
    
*/

// --- IMPORTO LOS ARCHIVOS NECESARIOS
const Combustible = require ("./combustible");

function Regular(id){

    Combustible.call(this, id, "Regular");
    
    this.cantidadDisponible = 1000;
    this.cantidadAlmacenamiento = 1000;
    this.tiempoRepostaje = 6;
    this.contadorRepostaje = 0;
    this.precioPorLitro = 1;

}

Regular.prototype = Object.create(Combustible.prototype);
Regular.prototype.constructor = Regular;

Regular.prototype.description = function(){

    var mensaje = "\n> Soy un combustible llamado " + this.nombre + ". Mi id es: " + this.getId() + ". Mi costo por litro es $" + this.precioPorLitro + " usd y tengo una capacidad de: " + this.cantidadDisponible + " lts.";

    return mensaje;
}

module.exports = Regular;