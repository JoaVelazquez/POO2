/*
    |------------------------------------|
    | TRABAJO PRÁCTICO N° 4: GASOLINERA  |
    | PROGRAMACIÓN ORIENTADA A OBJETOS 2 |
    |------------------------------------|
    | INTEGRANTES: AGUSTÍN MASSIERI      |
    |              JOAQUÍN VELAZQUEZ     |
    |------------------------------------|
    | PROFESOR: JOSE RUSCA               |
    |------------------------------------|
    
*/

// --- IMPORTO LOS ARCHIVOS NECESARIOS
const CombustiblesFactory = require("./combustiblesFactory");
const Gasolinera = require("./gasolinera");
const Stock = require("./stock");
const VehiculosFactory = require("./vehiculosFactory");


console.log("\n\n-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
console.log("---- BIENVENIDOS AL SISTEMA DE GASOLINERAS DE AGUSTIN Y JOAQUIN! ----\n");
console.log("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");

//Creo la fabrica de combustibles
console.log("--> Creo la fabrica de Combustibles\n");
var fabricaDeCombustibles = new CombustiblesFactory();

//Creo los 3 tipos de combustibles
console.log("--> Creo los 3 tipos de Combustibles mencionados en el enunciado: Regular, Premium, Diesel\n");
var regular = fabricaDeCombustibles.createCombustible("Regular");
var premium = fabricaDeCombustibles.createCombustible("Premium");
var diesel = fabricaDeCombustibles.createCombustible("Diesel");

//Creo el Stock
console.log("--> Creo el Stock\n");
//var stock = new Stock([]);

//Agrego los combustibles al Stock
console.log("--> Cargo los combustibles creados al Stock\n");
Stock.agregarCombustible(regular);
Stock.agregarCombustible(premium);
Stock.agregarCombustible(diesel);

//Muestro el Stock
console.log("--> Muestro el Stock: \n");
Stock.mostrarStock();

//Creo la Gasolinera
console.log("\n--> Creo la Gasolinera 'YPF'");
var ypf = new Gasolinera(1, "YPF", Stock);

//Muestro la Gasolinera
console.log(ypf.description());

//Muestro el Estado de los almacenes
ypf.mostrarEstadoAlmacenes();

//Creo la fabrica de vehiculos
console.log("\n--> Creo la fabrica de Vehiculos");
var fabricaDeVehiculos = new VehiculosFactory();

/*
//Creo los 3 tipos de vehiculos
console.log("\n--> Creo los 3 tipos de Vehiculos mencionados en el enunciado");
var moto = fabricaDeVehiculos.createVehiculo(2);
var auto = fabricaDeVehiculos.createVehiculo(4);
var camion = fabricaDeVehiculos.createVehiculo(6);

//Muestro a traves de la funcion description() las caracteristicas principales de cada uno
console.log(moto.description());
console.log(auto.description());
console.log(camion.description());
*/

console.log("\n\n----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
console.log("VAMOS A HACER LA PRUEBA DE GENERAR ALEATORIAMENTE VEHICULOS Y LUEGO VACIARLES EL COMBUSTIBLE PARA ASI PODER LLENARLES EL TANQUE Y VERIFICAR EL CORRECTO FUNCIONAMIENTO DE LA GASOLINERA\n");
console.log("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");

var listaVehiculos = []; //Creamos una lista para almacenar los vehiculos que crearemos aleatoriamente
  
//--- PARA GENERAR 100 VEHICULOS RANDOM ---

var i = 0;
var cantRuedas = [2,4,6];

while (i < 50 ){
    var ruedaRandom = cantRuedas[Math.floor(Math.random() *cantRuedas.length)]; //Generamos aleatoriamente un numero que sea 2, 4 o 6 (que son las cantidades de ruedas posibles para crear ya sea Moto, Auto o Camion)
    listaVehiculos.push(fabricaDeVehiculos.createVehiculo(ruedaRandom)); //Instanciamos y agregamos a la lista los vehiculos generados aleatoriamente por su numero de ruedas
    i += 1;
}

//--- PARA PROBAR COMO LE CARGAMOS EL COMBUSTIBLE 'REGULAR' E IMPRESION DEL TICKET ---


var j = 0;

while ( j < 50 ){

    listaVehiculos[j].combustibleDisponible = 0; //Le vaciamos el tanque de Combustible a cada Vehiculo
    
    var combustibleRandom =  listaVehiculos[j].tipoDeCombustible[Math.floor(Math.random() *( listaVehiculos[j].tipoDeCombustible).length)];

    switch (combustibleRandom){
        case 'Regular':

            ypf.cargarCombustible(regular, listaVehiculos[j]); //Le cargamos Combustible a cada Vehiculo
            break;
        
        case 'Premium':

            ypf.cargarCombustible(premium, listaVehiculos[j]); //Le cargamos Combustible a cada Vehiculo
            break;

        case 'Diesel':

            ypf.cargarCombustible(diesel, listaVehiculos[j]); //Le cargamos Combustible a cada Vehiculo
            break;

        default:
    }
    
    j += 1;
}

console.log("\n\n ", ypf.calcularGananciaTotal(ypf.cargarCombustibleDeUnaLista(listaVehiculos)));