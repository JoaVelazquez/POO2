/*
    |------------------------------------|
    | TRABAJO PRÁCTICO N° 4: GASOLINERA  |
    | PROGRAMACIÓN ORIENTADA A OBJETOS 2 |
    |------------------------------------|
    | INTEGRANTES: AGUSTÍN MASSIERI      |
    |              JOAQUÍN VELAZQUEZ     |
    |------------------------------------|
    | PROFESOR: JOSE RUSCA               |
    |------------------------------------|
    
*/

var Stock = (function (){  //MODULE PATTERN

    var listaDeCombustiblesStock = [];
    existeCombustibleEnStock = function(combustible){

        var flag = 0;
    
        listaDeCombustiblesStock.forEach(combustibleEnLista => {
    
            if( combustibleEnLista.getId() === combustible.getId() ){
                flag = 1;
            }
        });
    
        if (flag == 0){
            return false;
        }else{
            return true;
        }
    
    }
    return{
        mostrarStock : function(){
            if( listaDeCombustiblesStock.length > 0 ){

                listaDeCombustiblesStock.forEach( (combustibleEnLista, index) => {
                    console.log(index + 1, ") Combustible:", combustibleEnLista.nombre,"- Cantidad Disponible:", combustibleEnLista.cantidadDisponible, " lts - Capacidad Maxima:", combustibleEnLista.cantidadAlmacenamiento ,"- Precio por Litro: $", combustibleEnLista.precioPorLitro);
                });
        
            }else{
                console.log("Stock vacio!");
            }
        },
        agregarCombustible : function(combustible){
            var detectar  = 0;

            listaDeCombustiblesStock.forEach(combustibleEnLista => {
                if( combustibleEnLista.getId() === combustible.getId() ){
                    combustibleEnLista.cantidad += combustible.cantidadDisponible;
                    detectar = 1;
                }
            });

            if (detectar === 0){
                listaDeCombustiblesStock.push(combustible); 
            }
        },
        buscarCombustible : function(combustible){
    
            return listaDeCombustiblesStock.find( item => item.getId() == combustible.getId());
        },

        buscarCombustiblePorNombre : function(combustible){
    
            return listaDeCombustiblesStock.find( item => item.nombre == combustible);
        },

        modificarCombustible : function(combustible, precioNuevo,listaDeCombustiblesStock){

            if(existeCombustibleEnStock(combustible,listaDeCombustiblesStock)){
                
                listaDeCombustiblesStock.forEach(combustibleEnLista => {
                    if( combustibleEnLista.getId() === combustible.getId() ){
                        combustibleEnLista.precioPorLitro = precioNuevo;
                    }
                });
                
            }else{
                console.log("El combustible no esta en el Stock!");
            }
        },
        reducirCombustible : function(combustible, cantidadARecargar){

            if(existeCombustibleEnStock(combustible)){
                        
                listaDeCombustiblesStock.forEach(combustibleEnLista => {
                    
                    if( combustibleEnLista.getId() === combustible.getId() ){
        
                        combustibleEnLista.cantidadDisponible -= cantidadARecargar;
                    }
                });
                
            }else{
                console.log("El combustible no esta en el Stock!");
            }
        },
        llenarCombustible : function(combustible){

            if(existeCombustibleEnStock(combustible)){
                        
                listaDeCombustiblesStock.forEach(combustibleEnLista => {
                    
                    if( combustibleEnLista.getId() === combustible.getId() ){
        
                        combustibleEnLista.cantidadDisponible = combustibleEnLista.cantidadAlmacenamiento;
                    }
                });
                
            }else{
                console.log("El combustible no esta en el Stock!");
            }
        }
        
        }
        
})();
module.exports = Stock;

/*CODIGO ORIGINAL ---> PASADO A MODULE PATTERN 

function Stock(listaDeCombustiblesStock){

    this.listaDeCombustiblesStock = listaDeCombustiblesStock;
}

Stock.prototype.mostrarStock = function(){

    if( this.listaDeCombustiblesStock.length > 0 ){

        this.listaDeCombustiblesStock.forEach( (combustibleEnLista, index) => {
            console.log(index + 1, ") Combustible:", combustibleEnLista.nombre,"- Cantidad Disponible:", combustibleEnLista.cantidadDisponible, " lts - Capacidad Maxima:", combustibleEnLista.cantidadAlmacenamiento ,"- Precio por Litro: $", combustibleEnLista.precioPorLitro);
        });

    }else{
        console.log("Stock vacio!");
    }
}

Stock.prototype.agregarCombustible = function(combustible){
    
    var detectar  = 0;

    this.listaDeCombustiblesStock.forEach(combustibleEnLista => {
        if( combustibleEnLista.getId() === combustible.getId() ){
            combustibleEnLista.cantidad += combustible.cantidadDisponible;
            detectar = 1;
        }
    });

    if (detectar === 0){
        this.listaDeCombustiblesStock.push(combustible); 
    }
}

Stock.prototype.existeCombustibleEnStock = function(combustible){

    var flag = 0;

    this.listaDeCombustiblesStock.forEach(combustibleEnLista => {

        if( combustibleEnLista.getId() === combustible.getId() ){
            flag = 1;
        }
    });

    if (flag == 0){
        return false;
    }else{
        return true;
    }

}

Stock.prototype.buscarCombustible = function(combustible){
    
    return this.listaDeCombustiblesStock.find( item => item.getId() == combustible.getId());
}

Stock.prototype.modificarCombustible = function(combustible, precioNuevo){

    if(this.existeCombustibleEnStock(combustible)){
        
        this.listaDeCombustiblesStock.forEach(combustibleEnLista => {
            if( combustibleEnLista.getId() === combustible.getId() ){
                combustibleEnLista.precioPorLitro = precioNuevo;
            }
        });
        
    }else{
        console.log("El combustible no esta en el Stock!");
    }
}

Stock.prototype.reducirCombustible = function(combustible, cantidadARecargar){

    if(this.existeCombustibleEnStock(combustible)){
                
        this.listaDeCombustiblesStock.forEach(combustibleEnLista => {
            
            if( combustibleEnLista.getId() === combustible.getId() ){

                combustibleEnLista.cantidadDisponible -= cantidadARecargar;
            }
        });
        
    }else{
        console.log("El combustible no esta en el Stock!");
    }
}

Stock.prototype.llenarCombustible = function(combustible){

    if(this.existeCombustibleEnStock(combustible)){
                
        this.listaDeCombustiblesStock.forEach(combustibleEnLista => {
            
            if( combustibleEnLista.getId() === combustible.getId() ){

                combustibleEnLista.cantidadDisponible = combustibleEnLista.cantidadAlmacenamiento;
            }
        });
        
    }else{
        console.log("El combustible no esta en el Stock!");
    }
}
*/
