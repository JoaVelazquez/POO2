/*
    |------------------------------------|
    | TRABAJO PRÁCTICO N° 4: GASOLINERA  |
    | PROGRAMACIÓN ORIENTADA A OBJETOS 2 |
    |------------------------------------|
    | INTEGRANTES: AGUSTÍN MASSIERI      |
    |              JOAQUÍN VELAZQUEZ     |
    |------------------------------------|
    | PROFESOR: JOSE RUSCA               |
    |------------------------------------|
    
*/
const Transaccion = require("./transaccion");

function Gasolinera(id, nombre, stock){

    if(!(this instanceof Gasolinera)){  //Por si nos olvidamos el "new" en el main a la hora de instanciar la gasolinera
        return new Gasolinera(id, nombre);
    }

    var id = id;

    this.getId = function(){ //Getter del atributo privado Id
        return id;
    }
    
    this.nombre = nombre;
    this.stock = stock;
    this.listaDeTransacciones = [];
    this.contadorTransaccion_id = 0;

}

Gasolinera.prototype.description = function(){

    var mensaje = "\n--> Soy la Gasolinera: " + this.nombre + ". Mi Id es: " + this.getId() + ".";
    return mensaje;
}

Gasolinera.prototype.mostrarEstadoAlmacenes = function(){

    console.log("\nMuestro el Estado de los almacenes:\n");

    return this.stock.mostrarStock(); //Como los almacenes se manejan a traves del Stock, directamente invocamos a la funcion
}


Gasolinera.prototype.cargarCombustible = function(combustible, vehiculo){

	const combustibleEnStock = this.stock.buscarCombustible(combustible);
	
	if ( combustibleEnStock != undefined ){ //Verificamos que el combustible pasado por parametro exista en el Stock

		const cantidadARecargar = vehiculo.obtenerCantidaARecagrar(); //Metodo dentro del vehiculo que hace la resta entre los atributos de la 									      //capacidad del tanque
		 
		vehiculo.aumentarCantidadDisponible(cantidadARecargar) //Metodo dentro del vehiculo que aumenta el valor del atributo cantidadDisponible

		this.stock.reducirCombustible(combustible, cantidadARecargar); //Disminuimos el Stock
                                
        console.log("\n> Se cargo Combustible:", combustible.nombre, "correctamente en: ", vehiculo.nombre, ". El combustible disponible del 									vehiculo ahora es:", vehiculo.combustibleDisponible, "/", vehiculo.capacidadCombustible);
	
		this.nuevaTransaccion(combustible, vehiculo, cantidadARecargar);
       	this.verificaCantidadCombustible(combustible);

	}
	else{
		console.log("No hay Stock de ese combustible")
	}
}

Gasolinera.prototype.verificaCantidadCombustible = function(combustible){
//Justamente verificaremos que el objeto exista y que la cantidad sea suficiente
    const combustibleEnStock = this.stock.buscarCombustible(combustible);

    if ( combustibleEnStock != undefined ){ 

        if ( combustibleEnStock.cantidadDisponible <= 500 ){ //Verificamos la condicion para recargar el almacen
            
            if( combustible.contadorRepostaje +1 < combustible.tiempoRepostaje){
                combustible.contadorRepostaje += 1;
                console.log("\n> Hay menos de 500 lts disponibles de combuistible ",combustible.nombre ,"!");
                console.log("\n> Faltan ", combustible.tiempoRepostaje - combustible.contadorRepostaje," vehiculos para recargar el almacen de ",combustible.nombre ,".");
                
            }
            else{
                this.cargarAlmacen(combustible);
                combustible.contadorRepostaje = 0;
            }
        }
    }

    else{
        console.log("\nERROR: No existe el Combustible solicitado!");
    }
}

Gasolinera.prototype.cargarAlmacen = function(combustible){
 
    this.stock.llenarCombustible(combustible); //Recargamos el almacen del combustible pasado por parametro, tambien suponiendo que siempre se recargan hasta el maximo

    console.log("\nAlmacen de Combustible:", combustible.nombre, "recargado.");
}

Gasolinera.prototype.nuevaTransaccion = function(combustible, vehiculo, cantidadARecargar){

    this.contadorTransaccion_id += 1;

    const transaccion = new Transaccion(this.contadorTransaccion_id, vehiculo, combustible, cantidadARecargar); //Instanciamos la transaccion

    this.listaDeTransacciones.push(transaccion); //Agregamos la transaccion instanciada a la lista

    if ( (this.contadorTransaccion_id % 10) == 0){ //Verificamos si debe efectuar un cierre de caja

        this.cierreDeCaja(); //Ejectuamos el cierre de caja
    }
}

Gasolinera.prototype.cierreDeCaja = function(){

    var gananciaTotal = 0;
    console.log("\n\t\t\t\t--------------------------\n\t\t\t\t>> TICKET TRANSACCIONES <<\n\t\t\t\t--------------------------");
    console.log("ID_Transaccion\tID_Vehiculo\tVehiculo\t\tCombusitble\t\tCantidad_Recargada\tMonto");
    
    (this.listaDeTransacciones.slice(this.listaDeTransacciones.length - 10)).forEach(transaccion => {  //Voy a recorrer las ultimas 10 posiciones de la lista
        transaccion.description(); //Imprimo cada transaccion de forma indivual
        gananciaTotal += transaccion.monto; //Voy acumulando las ganancias individuales
    });
    
    console.log("\n\n               ----> CIERRE DE CAJA CON GANANCIA TOTAL DE: $", gananciaTotal.toFixed(0), "<----\n");
}


Gasolinera.prototype.cargarCombustibleDeUnaLista = function(listaDeVehiculos){

    listaDeVehiculos.forEach( vehiculo => {

        vehiculo.combustibleDisponible = 0; //Le vaciamos el tanque de Combustible a cada Vehiculo
        
        var combustibleRandom =  vehiculo.tipoDeCombustible[Math.floor(Math.random() * (vehiculo.tipoDeCombustible).length)];

        var combustibleEnStock = this.stock.buscarCombustiblePorNombre(combustibleRandom);
        
        if ( combustibleEnStock != undefined ){ //Verificamos que el combustible pasado por parametro exista en el Stock

            var cantidadARecargar = vehiculo.obtenerCantidaARecagrar(); //Metodo dentro del vehiculo que hace la resta entre los atributos de la 									      //capacidad del tanque
            
            vehiculo.aumentarCantidadDisponible(cantidadARecargar) //Metodo dentro del vehiculo que aumenta el valor del atributo cantidadDisponible

            this.stock.reducirCombustible(combustibleEnStock, cantidadARecargar); //Disminuimos el Stock
                                    
            //console.log("\n> Se cargo Combustible:", combustible.nombre, "correctamente en: ", vehiculo.nombre, ". El combustible disponible del vehiculo ahora es:", vehiculo.combustibleDisponible, "/", vehiculo.capacidadCombustible);
        
            this.nuevaTransaccion(combustibleEnStock, vehiculo, cantidadARecargar);
            this.verificaCantidadCombustible(combustibleEnStock);

        }
        else{
            console.log("No hay Stock de ese combustible")
        }

    })

    return this.listaDeTransacciones;

}

Gasolinera.prototype.calcularGananciaTotal = function(listaDeTransacciones){

    var gananciaTotal = 0;

    listaDeTransacciones.forEach(elemento => {
        gananciaTotal += elemento.monto;
    });

    return gananciaTotal;
}

module.exports = Gasolinera;