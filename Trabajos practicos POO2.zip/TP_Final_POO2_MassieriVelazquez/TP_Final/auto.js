/*
    |------------------------------------|
    | TRABAJO PRÁCTICO N° 4: GASOLINERA  |
    | PROGRAMACIÓN ORIENTADA A OBJETOS 2 |
    |------------------------------------|
    | INTEGRANTES: AGUSTÍN MASSIERI      |
    |              JOAQUÍN VELAZQUEZ     |
    |------------------------------------|
    | PROFESOR: JOSE RUSCA               |
    |------------------------------------|
    
*/

// --- IMPORTO LOS ARCHIVOS NECESARIOS
const Vehiculo = require("./vehiculo");

function Auto(id){

    Vehiculo.call(this, id, "Auto  ", ["Regular", "Premium"]);

    this.combustibleDisponible = 50;
    this.capacidadCombustible = 50;
    this.cantidadDeRuedas = 4;

}

Auto.prototype = Object.create(Vehiculo.prototype); 
Auto.prototype.constructor = Auto;

Auto.prototype.description = function(){
    var mensaje = "\n> Soy un Auto de " + this.cantidadDeRuedas + " ruedas. Mi Id es: " + this.getId() + ". El estado de mi tanque de combustible es: " + this.combustibleDisponible + "/" + this.capacidadCombustible + ". Mis tipos de combustible son: " + this.tipoDeCombustible;

    return mensaje;
}

module.exports = Auto;