/*
    |------------------------------------|
    | TRABAJO PRÁCTICO N° 4: GASOLINERA  |
    | PROGRAMACIÓN ORIENTADA A OBJETOS 2 |
    |------------------------------------|
    | INTEGRANTES: AGUSTÍN MASSIERI      |
    |              JOAQUÍN VELAZQUEZ     |
    |------------------------------------|
    | PROFESOR: JOSE RUSCA               |
    |------------------------------------|
    
*/

// --- IMPORTO LOS ARCHIVOS NECESARIOS
const Combustible = require("./combustible");

function Premium(id){

    Combustible.call(this, id, "Premium");

    this.cantidadDisponible = 750;
    this.cantidadAlmacenamiento = 750;
    this.tiempoRepostaje = 5;
    this.contadorRepostaje = 0;
    this.precioPorLitro = 2.3;

}

Premium.prototype = Object.create(Combustible.prototype); 
Premium.prototype.constructor = Premium;

Premium.prototype.description = function(){

    var mensaje = "\n> Soy un combustible llamado " + this.nombre + ". Mi id es: " + this.getId() + ". Mi costo por litro es $" + this.precioPorLitro + " usd y tengo una capacidad de: " + this.cantidadDisponible + " lts.";

    return mensaje;
}
module.exports = Premium;