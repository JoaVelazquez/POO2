/*
    |------------------------------------|
    | TRABAJO PRÁCTICO N° 4: GASOLINERA  |
    | PROGRAMACIÓN ORIENTADA A OBJETOS 2 |
    |------------------------------------|
    | INTEGRANTES: AGUSTÍN MASSIERI      |
    |              JOAQUÍN VELAZQUEZ     |
    |------------------------------------|
    | PROFESOR: JOSE RUSCA               |
    |------------------------------------|
    
*/

// --- IMPORTO LOS ARCHIVOS NECESARIOS
const Vehiculo = require("./vehiculo");

function Moto(id) {

    Vehiculo.call(this, id, "Moto  ", ["Regular", "Premium"]);

    this.combustibleDisponible = 10;
    this.capacidadCombustible = 10;
    this.cantidadDeRuedas = 2;
    
}

Moto.prototype = Object.create(Vehiculo.prototype); 
Moto.prototype.constructor = Moto;

Moto.prototype.description = function(){
    var mensaje = "\n> Soy una Moto de " + this.cantidadDeRuedas + " ruedas. Mi Id es: " + this.getId() + ". El estado de mi tanque de combustible es: " + this.combustibleDisponible + "/" + this.capacidadCombustible + ". Mis tipos de combustible son: " + this.tipoDeCombustible;

    return mensaje;
}

module.exports = Moto;