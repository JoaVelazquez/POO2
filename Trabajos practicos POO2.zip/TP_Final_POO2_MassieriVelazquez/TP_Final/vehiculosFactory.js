/*
    |------------------------------------|
    | TRABAJO PRÁCTICO N° 4: GASOLINERA  |
    | PROGRAMACIÓN ORIENTADA A OBJETOS 2 |
    |------------------------------------|
    | INTEGRANTES: AGUSTÍN MASSIERI      |
    |              JOAQUÍN VELAZQUEZ     |
    |------------------------------------|
    | PROFESOR: JOSE RUSCA               |
    |------------------------------------|
    
*/

// --- IMPORTO LOS ARCHIVOS NECESARIOS
const Auto = require('./Auto');
const Moto = require('./Moto');
const Camion = require('./Camion');

function VehiculosFactory(){  //Factory Method
    
    this.contador_id = 0;
}


VehiculosFactory.prototype.description = function(){

    var mensaje = "\n--> Soy la VehiculosFactory";
    return mensaje;
}

VehiculosFactory.prototype.createVehiculo = function(cantidadRuedas){

    if( cantidadRuedas == 2 ) {
        this.contador_id += 1;
        return new Moto(this.contador_id);
    }

    else if( cantidadRuedas == 4 ) {
        this.contador_id += 1;
        return new Auto(this.contador_id);
    }

    else if( cantidadRuedas == 6  ) {
        this.contador_id += 1;
        return new Camion(this.contador_id);
    }

    console.log('\n> No se encontro ese vehiculo en la VehiculosFactory!');

}

module.exports = VehiculosFactory;