/*
    |------------------------------------|
    | TRABAJO PRÁCTICO N° 4: GASOLINERA  |
    | PROGRAMACIÓN ORIENTADA A OBJETOS 2 |
    |------------------------------------|
    | INTEGRANTES: AGUSTÍN MASSIERI      |
    |              JOAQUÍN VELAZQUEZ     |
    |------------------------------------|
    | PROFESOR: JOSE RUSCA               |
    |------------------------------------|
    
*/

function Combustible(id, nombre, tiempoRepostaje ) {

    if(!(this instanceof Combustible)){  //Por si nos olvidamos el "new" en el main a la hora de instanciar el combustible
        return new Combustible(id, nombre);
    }

    var id = id;
    this.nombre = nombre;

    this.getId = function(){
        return id;
    }

    this.tiempoRepostaje = 0; //este esta dado en cantidad de autos
    this.contadorRepostaje = 0; //este contador sirve para saber cuando se debe recargar el almacen
    this.cantidadDisponible = 0;
    this.cantidadAlmacenamiento = 0;
    this.precioPorLitro = 0;

}


Combustible.prototype.description = function(){
    var mensaje =  "\n> Soy un Combustible llamado: " + this.nombre + " .Mi id es: " + this.getId() + ".";
    
    return mensaje;
}

module.exports = Combustible;