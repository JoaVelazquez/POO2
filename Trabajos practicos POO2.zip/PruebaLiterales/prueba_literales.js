//LITERALES
var j = {
    dni : 39437187,
    nombre : "Joaquin",
    apellido : "Velazquez",
    saldoEnPesos : 10000,

    depositar: function(monto){
        if (monto > 0){

            this.saldoEnPesos += monto; 
        }
        else{
            console.log("Monto invalido!");
        }
    }
}
console.log(j);
j.depositar(50);
console.log(j);
console.log('\n------\n');

var james = Object.create(j);
james.nombre = 'James';
james.apellido = 'Hetfield';
james.saldoEnPesos = 25000;
console.log(james);
james.depositar(55);
console.log(james);
//CONSTRUCTOR


function Cuenta(dni,nombre, apellido, saldoEnPesos){
    this.dni = dni;     
    this.nombre = nombre;
    this.apellido = apellido;
    this.saldoEnPesos = saldoEnPesos;
    this.depositar = function(monto){
        if (monto > 0){
    
            this.saldoEnPesos += monto; 
        }
        else{
            console.log("Monto invalido!");
        }
    }
}
var cuentaConstr1 = new Cuenta(21456789,'Kakashi','Hatake',15000);
console.log(cuentaConstr1);