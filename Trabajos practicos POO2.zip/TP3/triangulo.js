const FiguraGeometrica = require('./FiguraGeometrica');


function Triangulo(id){

    if(!(this instanceof Triangulo)){  //Por si nos olvidamos el "new" en el main a la hora de instanciar la figura
        return new Triangulo(id);
    }
    
    FiguraGeometrica.call(this, id, 'Triangulo', 3, '2D');

    this.base = 10;
    this.altura = 20;

    this.setAltura = function(altura){
        
        if ( altura <= 0 ){

            console.log("No se puede asignar una altura <= 0!");
        }
        else{
            
            this.altura = altura;
        }
    }

    this.setBase = function(base){

        if ( base <= 0 ){

            console.log("No se puede asignar una base <= 0!");
        }
        else{
            
            this.base = base;
        }
    }

}
   
Triangulo.prototype = Object.create(FiguraGeometrica.prototype); 
Triangulo.prototype.constructor = Triangulo;

Triangulo.prototype.calcularPerimetro = function(){

    return 3 * this.base;

}

Triangulo.prototype.calcularArea = function(){

    return (this.base * this.altura) / 2;

}

Triangulo.prototype.calcularPrecio = function(material){
    
    if (material == "acero"){
        return 100 * this.calcularArea();
    }

    else if (material == "platino"){
        return 250 * this.calcularArea();
    }
}

module.exports = Triangulo;