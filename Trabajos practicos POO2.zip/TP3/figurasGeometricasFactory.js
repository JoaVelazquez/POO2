const Pentagono = require('./Pentagono');
const Piramide = require('./Piramide');
const PrismaPentagonal = require('./PrismaPentagonal');
const Triangulo = require('./Triangulo');
const Circulo = require('./Circulo');
const Cuadrado = require('./Cuadrado');
const Cubo = require('./Cubo');
const Esfera = require('./Esfera');

function FigurasGeometricasFactory(identificador){
    
    this.contador_id = 0;

    this.identificador = identificador;
    
}

FigurasGeometricasFactory.prototype.description = function(){

    console.log("\n--> Soy la FigurasGeometricasFactory N°:" , this.identificador);
}

FigurasGeometricasFactory.prototype.createFiguraGeometrica = function(numLados, dimension){

    if( (numLados == 0) && (dimension == '2D') ) {
        this.contador_id += 1;
        return new Circulo(this.contador_id);
    }

    if( (numLados == 3) && (dimension == '2D') ) {
        this.contador_id += 1;
        return new Triangulo(this.contador_id);
    }    

    if( (numLados == 4) && (dimension == '2D') ) {
        this.contador_id += 1;
        return new Cuadrado(this.contador_id); 
    }
            
    if( (numLados == 5) && (dimension == '2D') ) {
        this.contador_id += 1;
        return new Pentagono(this.contador_id);  
    }

    if( (numLados == 0) && (dimension == '3D') ) {
        this.contador_id += 1;
        return new Esfera(this.contador_id);  
    }

    if( (numLados == 3) && (dimension == '3D') ) {
        this.contador_id += 1;
        return new Piramide(this.contador_id);  
    }

    if( (numLados == 4) && (dimension == '3D') ) {
        this.contador_id += 1;
        return new Cubo(this.contador_id);  
    }

    if( (numLados == 5) && (dimension == '3D') ) {
        this.contador_id += 1;
        return new PrismaPentagonal(this.contador_id);  
    }

    console.log('\n> No se encontro esa figura en la FigurasGeometricaFactory!');

}

module.exports = FigurasGeometricasFactory;