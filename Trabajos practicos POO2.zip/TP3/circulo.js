const FiguraGeometrica = require('./FiguraGeometrica');


function Circulo(id){

    if(!(this instanceof Circulo)){  //Por si nos olvidamos el "new" en el main a la hora de instanciar la figura
        return new Circulo(id);
    }
    
    FiguraGeometrica.call(this, id, 'Circulo', 0, '2D');
    this.radio = 10;

    this.setRadio = function(radio){

        if( radio <= 0 ){

            console.log("No se puede asignar un radio <= 0!")
        }
        else{
            
            this.radio = radio;
        }
    }

}
   
Circulo.prototype = Object.create(FiguraGeometrica.prototype); 
Circulo.prototype.constructor = Circulo;

Circulo.prototype.calcularPerimetro = function(){  
   
    return 2 * Math.PI * this.radio;
}

Circulo.prototype.calcularArea = function(){
        
    return Math.PI * Math.pow(this.radio,2);
    
}

Circulo.prototype.calcularPrecio = function(material){
    
    if (material == "acero"){
        return 100 * this.calcularArea();
    }

    else if (material == "platino"){
        return 250 * this.calcularArea();
    }
}

module.exports = Circulo;