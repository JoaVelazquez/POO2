const FiguraGeometrica = require('./FiguraGeometrica');


function Cuadrado(id){
    
    if(!(this instanceof Cuadrado)){  //Por si nos olvidamos el "new" en el main a la hora de instanciar la figura
        return new Cuadrado(id);
    }

    FiguraGeometrica.call(this, id, 'Cuadrado', 4, '2D');
    this.lado = 10;

    this.setLado = function(lado){

        if( lado <= 0 ){
            console.log("No se puede asignar un lado <=0!");
        }
            
        else{
            this.lado = lado;
        } 
    }
}
   
Cuadrado.prototype = Object.create(FiguraGeometrica.prototype); 
Cuadrado.prototype.constructor = Cuadrado;

Cuadrado.prototype.calcularPerimetro = function(){

    return 4 * this.lado;

}

Cuadrado.prototype.calcularArea = function(){

    return Math.pow(this.lado, 2);

}

Cuadrado.prototype.calcularPrecio = function(material){
    
    if (material == "acero"){
        return 100 * this.calcularArea();
    }

    else if (material == "platino"){
        return 250 * this.calcularArea();
    }
}



module.exports = Cuadrado;