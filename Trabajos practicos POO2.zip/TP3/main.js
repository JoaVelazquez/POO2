const FigurasGeometricasFactory = require('./FigurasGeometricasFactory');
const Circulo = require('./Circulo');

console.log("\n---- BIENVENIDOS AL PROGRAMA DE PATRONES/TDD/FACTORY METHOD DE JOAQUIN Y AGUSTIN! ----\n");

contador_id = 0;

const factory = new FigurasGeometricasFactory(1); //Creo mi fabrica de Figuras Geometricas
factory.description();

const circulo = factory.createFiguraGeometrica(0, '2D'); //Creo una figura "circulo" usando la fabrica
console.log(circulo.description());

console.log("\n   > Le pongo al circulo un radio = 20.");
circulo.setRadio(20);

console.log("\n   > Calculo el perimetro y area del circulo: ");
console.log("\n     > Perimetro = ", circulo.calcularPerimetro());
console.log("\n     > Area = ", circulo.calcularArea());


const triangulo = factory.createFiguraGeometrica(3, '2D'); //Creo una figura "triangulo" usando la fabrica
console.log(triangulo.description());

console.log("\n   > Le pongo al triangulo base = 15 y altura = 12");
triangulo.setAltura(12);
triangulo.setBase(15);

console.log("\n   > Calculo el perimetro y area del triangulo: ");
console.log("\n     > Perimetro = ", triangulo.calcularPerimetro());
console.log("\n     > Area = ", triangulo.calcularArea());


const cuadrado = factory.createFiguraGeometrica(4, '2D'); //Creo una figura "cuadrado" usando la fabrica
console.log(cuadrado.description());

console.log("\n   > Le pongo al cuadrado lado = 28");
cuadrado.setLado(28);

console.log("\n   > Calculo el perimetro y area del cuadrado: ");
console.log("\n     > Perimetro = ", cuadrado.calcularPerimetro());
console.log("\n     > Area = ", cuadrado.calcularArea());


const pentagono = factory.createFiguraGeometrica(5, '2D'); //Creo una figura "pentagono" usando la fabrica
console.log(pentagono.description());

console.log("\n   > Le pongo al pentagono lado = 15 y apotema = 14");
pentagono.setLado(15);
pentagono.setApotema(14);

console.log("\n   > Calculo el perimetro y area del pentagono: ");
console.log("\n     > Perimetro = ", pentagono.calcularPerimetro());
console.log("\n     > Area = ", pentagono.calcularArea());


const esfera = factory.createFiguraGeometrica(0, '3D'); //Creo una figura "esfera" usando la fabrica
console.log(esfera.description());

console.log("\n   > Le pongo a la esfera un radio = 20.");
esfera.setRadio(20);

console.log("\n   > Calculo el volumen de la esfera: ");
console.log("\n     > Volumen = ", esfera.calcularVolumen());


const piramide = factory.createFiguraGeometrica(3, '3D'); //Creo una figura "piramide" usando la fabrica
console.log(piramide.description());

console.log("\n   > Le pongo a la piramide base = 15 y altura = 12");
piramide.setAltura(12);
piramide.setBase(15);

console.log("\n   > Calculo el volumena de la piramide: ");
console.log("\n     > Volumen = ", piramide.calcularVolumen());


const cubo = factory.createFiguraGeometrica(4, '3D'); //Creo una figura "cubo" usando la fabrica
console.log(cubo.description());

console.log("\n   > Le pongo al cubo lado = 28");
cubo.setLado(28);

console.log("\n   > Calculo el volumen del cubo: ");
console.log("\n     > Volumen = ", cubo.calcularVolumen());


const prismaPentagonal = factory.createFiguraGeometrica(5, '3D'); //Creo una figura "prismaPentagonal" usando la fabrica
console.log(prismaPentagonal.description());

console.log("\n   > Le pongo al Prisma Pentagonal lado = 15, apotema = 14 y altura = 12");
prismaPentagonal.setLado(15);
prismaPentagonal.setApotema(14);
prismaPentagonal.setAltura(12);

console.log("\n   > Calculo el volumen del Prisma Pentagonal: ");
console.log("\n     > Volumen = ", prismaPentagonal.calcularVolumen());


const octagono = factory.createFiguraGeometrica(8, '2D'); //Creo una figura "octagono" usando la fabrica PERO que no se encuentra programa (nos deberia devolver error)

const circulo1 = Circulo(9); //Muestro como sin el new, me crea un nuevo circulo igualmente gracias al ...   if(!(this instanceof Circulo)){
console.log(circulo1.description());                                                                      //     return new Circulo(id);
                                                                                                          // }


console.log("\n\n --- CREAMOS OTRA FIGURA MAS DE CADA TIPO COMO PEDIA EL ENUNCIADO ---\n");

const factory2 = new FigurasGeometricasFactory(2); //Intento crear otra Fabrica de Figuras Geometricas pero no deberia crear una nueva que ya fue instanciada!
factory2.description();


const circulo2 = factory.createFiguraGeometrica(0, '2D'); //Creo una figura "circulo" usando la fabrica
console.log(circulo2.description());

console.log("\n   > Le pongo al circulo un radio = 15.");
circulo2.setRadio(15);

console.log("\n   > Calculo el perimetro y area del circulo: ");
console.log("\n     > Perimetro = ", circulo2.calcularPerimetro());
console.log("\n     > Area = ", circulo2.calcularArea());


const triangulo2 = factory.createFiguraGeometrica(3, '2D'); //Creo una figura "triangulo" usando la fabrica
console.log(triangulo2.description());

console.log("\n   > Le pongo al triangulo base = 5 y altura = 3");
triangulo2.setAltura(5);
triangulo2.setBase(3);

console.log("\n   > Calculo el perimetro y area del triangulo: ");
console.log("\n     > Perimetro = ", triangulo2.calcularPerimetro());
console.log("\n     > Area = ", triangulo2.calcularArea());


const cuadrado2 = factory.createFiguraGeometrica(4, '2D'); //Creo una figura "cuadrado" usando la fabrica
console.log(cuadrado2.description());

console.log("\n   > Le pongo al cuadrado lado = 9");
cuadrado2.setLado(9);

console.log("\n   > Calculo el perimetro y area del cuadrado: ");
console.log("\n     > Perimetro = ", cuadrado2.calcularPerimetro());
console.log("\n     > Area = ", cuadrado2.calcularArea());


const pentagono2 = factory.createFiguraGeometrica(5, '2D'); //Creo una figura "pentagono" usando la fabrica
console.log(pentagono2.description());

console.log("\n   > Le pongo al pentagono lado = 13 y apotema = 4");
pentagono2.setLado(13);
pentagono2.setApotema(4);

console.log("\n   > Calculo el perimetro y area del pentagono: ");
console.log("\n     > Perimetro = ", pentagono2.calcularPerimetro());
console.log("\n     > Area = ", pentagono2.calcularArea());


const esfera2 = factory.createFiguraGeometrica(0, '3D'); //Creo una figura "esfera" usando la fabrica
console.log(esfera2.description());

console.log("\n   > Le pongo a la esfera un radio = 23.");
esfera2.setRadio(23);

console.log("\n   > Calculo el volumen de la esfera: ");
console.log("\n     > Volumen = ", esfera2.calcularVolumen());


const piramide2 = factory.createFiguraGeometrica(3, '3D'); //Creo una figura "piramide" usando la fabrica
console.log(piramide2.description());

console.log("\n   > Le pongo a la piramide base = 5 y altura = 2");
piramide2.setAltura(5);
piramide2.setBase(2);

console.log("\n   > Calculo el volumena de la piramide: ");
console.log("\n     > Volumen = ", piramide2.calcularVolumen());


const cubo2 = factory.createFiguraGeometrica(4, '3D'); //Creo una figura "cubo" usando la fabrica
console.log(cubo2.description());

console.log("\n   > Le pongo al cubo lado = 6");
cubo2.setLado(6);

console.log("\n   > Calculo el volumen del cubo: ");
console.log("\n     > Volumen = ", cubo2.calcularVolumen());


const prismaPentagonal2 = factory.createFiguraGeometrica(5, '3D'); //Creo una figura "prismaPentagonal" usando la fabrica
console.log(prismaPentagonal2.description());

console.log("\n   > Le pongo al Prisma Pentagonal lado = 4, apotema = 3 y altura = 2");
prismaPentagonal2.setLado(4);
prismaPentagonal2.setApotema(3);
prismaPentagonal2.setAltura(2);

console.log("\n   > Calculo el volumen del Prisma Pentagonal: ");
console.log("\n     > Volumen = ", prismaPentagonal2.calcularVolumen());

console.log("\n");