function FiguraGeometrica(id, nombre, numLados, dimension) {
    
    if(!(this instanceof FiguraGeometrica)){  //Por si nos olvidamos el "new" en el main a la hora de instanciar la figura
        return new FiguraGeometrica(id, nombre, numLados, dimension);
    }

    var id = id;
    this.nombre = nombre;

    if( numLados >= 0){
        
        this.numLados = numLados;
    }
    else{
        console.log("No se puede crear una Figura Geometrica con n° de lados negativo!");
    }
    
    this.dimension = dimension;

    this.getId = function(){
        return id;
    }

}

FiguraGeometrica.prototype.description = function(){
    var mensaje =  "\n> Soy una Figura Geometrica llamada: " + this.nombre + " y tengo: " + this.numLados + " lados! Mi id es: " + this.getId() + " y mi dimesion es: " + this.dimension + ".";
    
    return mensaje;
}

module.exports = FiguraGeometrica;