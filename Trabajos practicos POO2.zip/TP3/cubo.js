const Cuadrado = require('./Cuadrado');


function Cubo(id){
    
    if(!(this instanceof Cubo)){  //Por si nos olvidamos el "new" en el main a la hora de instanciar la figura
        return new Cubo(id);
    }
    
    Cuadrado.call(this, id, 'Cubo', 4, '3D');
}
   
Cubo.prototype = Object.create(Cuadrado.prototype); 
Cubo.prototype.constructor = Cubo;

Cubo.prototype.description = function(){
    var mensaje =  "\n> Soy una Figura Geometrica llamada: Cubo y tengo: " + this.numLados + " lados! Mi id es: " + this.getId()+ " y mi dimesion es: 3D.";
    
    return mensaje;
}

Cubo.prototype.calcularVolumen = function(){

    return Math.pow(this.lado, 3);

}

Cubo.prototype.calcularPrecio = function(material){
    
    if (material == "acero"){
        return 1000 * this.calcularVolumen();
    }

    else if (material == "platino"){
        return 2500 * this.calcularVolumen();
    }
}

module.exports = Cubo;