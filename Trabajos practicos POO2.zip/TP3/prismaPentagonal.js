const Pentagono = require('./Pentagono');


function PrismaPentagonal(id){
    
    if(!(this instanceof PrismaPentagonal)){  //Por si nos olvidamos el "new" en el main a la hora de instanciar la figura
        return new PrismaPentagonal(id);
    }

    Pentagono.call(this, id, 'Prisma Pentagonal', 5, '3D');
    this.altura = 10;

    this.setAltura = function(altura){

        if ( altura <= 0 ){
            console.log("No se puede asignar una altura <= 0!");
        }
        else{
            this.altura = altura;
        }
        
    }
}
   
PrismaPentagonal.prototype = Object.create(Pentagono.prototype); 
PrismaPentagonal.prototype.constructor = PrismaPentagonal;

PrismaPentagonal.prototype.description = function(){
    var mensaje =  "\n> Soy una Figura Geometrica llamada: Prisma Pentagonal y tengo: " + this.numLados + " lados! Mi id es: " + this.getId() + " y mi dimesion es: 3D.";
    
    return mensaje;
}

PrismaPentagonal.prototype.calcularVolumen = function(){

    return this.calcularArea() * this.altura
}

PrismaPentagonal.prototype.calcularPrecio = function(material){
    
    if (material == "acero"){
        return 1000 * this.calcularVolumen();
    }

    else if (material == "platino"){
        return 2500 * this.calcularVolumen();
    }
}

module.exports = PrismaPentagonal;
