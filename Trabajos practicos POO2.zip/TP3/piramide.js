const Triangulo = require('./Triangulo');

function Piramide(id){
    
    if(!(this instanceof Piramide)){  //Por si nos olvidamos el "new" en el main a la hora de instanciar la figura
        return new Piramide(id);
    }

    Triangulo.call(this, id, 'Piramide', 3, '3D');
}
   
Piramide.prototype = Object.create(Triangulo.prototype); 
Piramide.prototype.constructor = Piramide;

Piramide.prototype.description = function(){
    var mensaje =  "\n> Soy una Figura Geometrica llamada: Piramide y tengo: " + this.numLados + " lados! Mi id es: " + this.getId() + " y mi dimesion es: 3D.";
    
    return mensaje;
}

Piramide.prototype.calcularVolumen = function(){
    
    return (1/3) * this.base * this.altura;
}

Piramide.prototype.calcularPrecio = function(material){
    
    if (material == "acero"){
        return 1000 * this.calcularVolumen();
    }

    else if (material == "platino"){
        return 2500 * this.calcularVolumen();
    }
}

module.exports = Piramide;