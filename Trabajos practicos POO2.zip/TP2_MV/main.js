/*function Cliente (nombre, dni, carrito){

    this.nombre = nombre;
    var dni = dni;
    this.carrito = carrito;
    
    this.obtenerDNI = function(){
        return dni;
    }
        
}

Cliente.prototype.muestrate = function(){
    
    var mensaje = "> Soy " + this.nombre + this.apellido + "D.N.I: " + this.obtenerDNI();
    return mensaje;
}


function Carrito(){

    listaProductosCarrito = [];

}

Carrito.prototype.muestrate = function(){
    
    if( this.listaProductosCarrito.length > 0 ){
        this.listaProductosCarrito.forEach(producto => {console.log(this.listaProductosCarrito.indexOf(producto) + 1, ") Producto: ",producto.nombre,"- Cantidad: ", producto.cantidad)})
    }else{
        console.log("Carrito vacio!");
    }
}


function Stock() {
    
    listaProductosStock = [];
}

Stock.prototype.muestrate = function(){
    
    if( this.listaProductosStock.length > 0 ){
        this.listaProductosStock.forEach(producto => {console.log(this.listaProductosStock.indexOf(producto) + 1, ") Producto: ",producto.nombre,"- Cantidad: ", producto.cantidad)})
    }else{
        console.log("Stock vacio!");
    }
}
*/

function Producto(id, nombre, costo, cantidad) {
    
    var id = id;
    this.nombre = nombre;
    this.costo = costo;
    this.cantidad = cantidad;

    this.obtenerId = function(){
        return id;
    }
}

Producto.prototype.muestrate = function(){
    
    var mensaje = "ID: " + this.obtenerId() + " - Nombre: " + this.nombre + " - Costo: $" + this.costo + " - Cantidad: " + this.cantidad; 
}


function ProductoPerecedero(id, nombre, costo, cantidad, fechaDeCaducidad){
    
    Producto.call(this, id, nombre, costo, cantidad);
    var fechaDeCaducidad = fechaDeCaducidad;

    this.obtenerFechaDeCaducidad = function(){
        return fechaDeCaducidad;
    }
}

ProductoPerecedero.prototype = Object.create(Producto.prototype);
ProductoPerecedero.prototype.constructor = ProductoPerecedero;

ProductoPerecedero.prototype.muestrate = function(){
    
    var mensaje = "--ProdPerecedero\n>Nombre del producto: " + this.nombre+"\n>Id del producto: " + this.obtenerId() +
    "\n>Costo: $" + this.costo+"\n>Cantidad: " + this.cantidad + "\n>Fecha caducidad: " + this.obtenerFechaDeCaducidad();
    return mensaje;
}

function ProductoPerecederoRefrigeracion(id, nombre, costo, cantidad, fechaCaducidad, tipoRefrigeracion){
    
    ProductoPerecedero(this, id, nombre, costo, cantidad, fechaCaducidad);
    var tipoRefrigeracion = tipoRefrigeracion;

    this.obtenerTipoRefrigeracion = function(){
        return tipoRefrigeracion;
    }
}

ProductoPerecederoRefrigeracion.prototype = Object.create(ProductoPerecedero.prototype);
ProductoPerecederoRefrigeracion.prototype.constructor = ProductoPerecederoRefrigeracion;

ProductoPerecederoRefrigeracion.prototype.muestrate = function(){
    
    var mensaje = "--ProdRefrg\n>Nombre del producto: " + this.nombre+"\n>Id del producto: " + this.obtenerId() +
    "\n>Costo: $" + this.costo+"\n>Cantidad: " + this.cantidad + "\n>Tipo regrigeracion: " + this.obtenerTipoRefrigeracion()
    + "\n>Fecha caducidad: " + this.obtenerFechaDeCaducidad();
    return mensaje;
}

function ProductoLineaBlanca(id, nombre, costo, cantidad,){

    Producto.call(this, id, nombre, costo, cantidad);
    var largo = largo;
    var ancho = ancho;
    var profundidad = profundidad;

    this.obtenerLargo= function(){
        return largo;
    }

    this.obtenerAncho= function(){
        return ancho;
    }

    this.obtenerProfundidad= function(){
        return profundidad;
    }
}

ProductoLineaBlanca.prototype = Object.create(Producto.prototype);
ProductoLineaBlanca.prototype.constructor = ProductoLineaBlanca;

ProductoLineaBlanca.prototype.muestrate = function(){
    
    var mensaje = "--ProdLineaBlanca\n>Nombre del producto: " + this.nombre+"\n>Id del producto: " + this.obtenerId() +
    "\n>Costo: $" + this.costo + "\n>Cantidad: " + this.cantidad + "\n>Dimensiones(L,A,P): ( " +
    this.obtenerLargo() + "," + this.obtenerAncho() + "," + this.obtenerProfundidad() + " )";
    return mensaje;
}


/*
-cliente
-carrito
-stock
-prodcuto
    -linea blanca
    -perecedero
        -refrigeracion

*/


//------------------- MAIN ---------------------

 
var pan = new ProductoPerecedero(1, "Pan", 10, 0, new Date(2021, 12, 30));
var manteca = new ProductoPerecederoRefrigeracion(2, "Manteca", 2000, 120, new Date(2021, 10, 29), "Heladera");
var helado = new ProductoPerecederoRefrigeracion(3, "Helado", 400, 500, new Date(2021, 10, 15), "Freezer");
var lavarropas = new ProductoLineaBlanca(4, "Lavarropas", 500, 10, 3.5, 4, 6);
/*
var carritoJose = new Carrito();
var carritoLennin = new Carrito();

var jose = new Cliente("Jose", 123456789, carritoJose);
var lennin = new Cliente("Lennin", 987654321, carritoLennin);*/

console.log(pan.muestrate(), "\n");
console.log(manteca.muestrate(), "\n");
console.log(helado.muestrate(), "\n");
console.log(lavarropas.muestrate(), "\n");

