function Cuenta (dni, nombre, apellido, saldoP){
    Cuenta.contador = ++Cuenta.contador || 1;
    this.id = Cuenta.contador;
    var dni = dni;
    this.nombre = nombre;
    this.apellido = apellido;
    this.saldoP = saldoP;

    function shareDni(){
        return dni;
    }
    this.obtenerDNI = function(){ //se puede poner simplemente return dni y scar la funcion shareDNI
        return shareDni();
    }
}

Cuenta.prototype.depositaP = function(monto){
    if(monto < 0){
        console.log("Monto invalido")
    }else{
        this.saldoP = this.saldoP + monto;
    }
}

Cuenta.prototype.retirarP = function(monto){
    if(monto > this.saldoP){
        console.log("saldo Insuficiente")
    }else{
        this.saldoP = this.saldoP - monto;
    }
}

Cuenta.prototype.muestrate = function(){
    var mensaje =this.id+ ".- " + this.nombre +" "+ this.apellido+" --> "+ this.saldoP;
    return mensaje;
}

function CuentaE(dni,nombre,apellido,saldoP,saldoD,saldoE){
    Cuenta.call(this, dni, nombre, apellido, saldoP);
    this.saldoD = saldoD;
    this.saldoE = saldoE;
}

CuentaE.prototype = Object.create(Cuenta.prototype);
CuentaE.prototype.constructor = CuentaE;

CuentaE.prototype.muestrate = function(){
    var mensaje =this.obtenerDNI() + " "+ this.id+ ".- "+ " "+ this.nombre +" "+ this.apellido+" tiene "+ this.saldoP + " pesos, "+this.saldoD+" dolares y "+this.saldoE+" euros";
    return mensaje;
};

CuentaE.prototype.depositaD = function(monto){
    if(monto < 0){
        console.log("Monto invalido")
    }else{
        this.saldoD = this.saldoD + monto;
    }
}

CuentaE.prototype.retiraD = function(monto){
    if(monto > this.saldoD){
        console.log("saldo Insuficiente")
    }else{
        this.saldoD = this.saldoD - monto;
    }
}
CuentaE.prototype.depositaE = function(monto){
    if(monto < 0){
        console.log("Monto invalido")
    }else{
        this.saldoE = this.saldoE + monto;
    }
}

CuentaE.prototype.retiraE = function(monto){
    if(monto > this.saldoE){
        console.log("saldo Insuficiente")
    }else{
        this.saldoE = this.saldoE - monto;
    }
}

function CuentaVIP(dni, nombre, apellido, saldoP, saldoD, saldoE, montoPrestamo){
    CuentaE.call(this,dni, nombre, apellido, saldoP, saldoD, saldoE)
    this.montoPrestamo = montoPrestamo;
}
CuentaVIP.prototype = Object.create(CuentaE.prototype);
CuentaVIP.prototype.constructor = CuentaVIP;

CuentaVIP.prototype.pedirPrestamo = function(){
    this.saldoP = this.saldoP + this.montoPrestamo;
}

var c1=new Cuenta (122442, "Lupita", "Hernadez", 9800);
var ce1=new CuentaE(7293732, "Rodrigo", "Fuentes", 750, 4500, 7600);
var cvip1 = new CuentaVIP(2846223, "Jorge", "Fernandez", 300, 500, 700, 15000);

console.log(c1.nombre);
console.log(c1.obtenerDNI());
c1.depositaP(75);
c1.retirarP(20);
ce1.depositaP(45);
ce1.retirarP(10);
ce1.depositaD(7);
ce1.retiraD(3);
ce1.depositaE(8);
ce1.retiraE(2);

cvip1.depositaP(10000);
cvip1.retirarP(5400);
cvip1.depositaD(60);
cvip1.retiraD(57);
cvip1.depositaE(35);
cvip1.retiraE(24);
cvip1.pedirPrestamo();





console.log(c1.muestrate());
console.log(ce1.muestrate());
console.log(cvip1.muestrate());

