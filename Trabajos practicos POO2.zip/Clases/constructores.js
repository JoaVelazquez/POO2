//un constructor en js es una fun que se invoca con el operador new y nos va a ser de plantilla
function Persona( nombre, apellido, fechaNac){
    this.nombre = nombre;
    this.apellido = apellido;
    this.fechaNac = fechaNac;
    this.nombreCompleto = function(){
        return this.apellido + ", " + this.nombre + ", " + this.fechaNac.toLocaleDateString();
    }
}

var javier = new Persona("Javier","Baez", new Date());
Persona.prototype.telefono = '123456789';
var carlos = new Persona("Carlos","Martinez", new Date());
console.log(javier);
console.log(carlos.telefono);
/*
function varlist(){
    return Object.getOwnPropertyNames(this);
}
console.log(varlist());
*/