function funcPersona(nombre, apellido, fechaNac){
    var persona = {};
    persona.nombre = nombre;
    persona.apellido = apellido;
    persona.fechaNac = fechaNac;
    persona.nombreCompleto = function(){
        return persona.apellido+" ,"+persona.nombre+" ,"+persona.fechaNac.toLocalDateString();
    }
    return persona;
}
var javier = funcPersona("Javier","Baez",new Date());
console.log(javier.nombreCompleto());

function Persona(nombre, apellido, fechaNac){
    if(!(this instanceof Persona))
    return new
    var persona = {};
    persona.nombre = nombre;
    persona.apellido = apellido;
    persona.fechaNac = fechaNac;
    persona.nombreCompleto = function(){
        return persona.apellido+" ,"+persona.nombre+" ,"+persona.fechaNac.toLocalDateString();
    }
    return persona;
}
var juan = Persona("Juan","Ortega",new Date());
