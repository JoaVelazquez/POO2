/*
var javier = {
    nombre : "Javier",
    apellido : "Baez",
    fechaNacimiento : new Date(1998, 6, 15),
    nombreCompleto: function(){
        return this.apellido + ", " + this.nombre + ", " + this.fechaNacimiento;
    }
}

var adam = Object.create(javier);
console.log(javier);
adam.nombre = 'Adam';
adam.apellido = 'Khanwald'
console.log(adam);
//aca el objeto javier se clono en adam, pero cuando le llamamos algun atributo, por ejemplo el nombre
// el clon le pide al prototipo.

for( const prop in javier){
    console.log('- '+prop);
}
console.log(Object.getOwnProperty)
*/
//CLASE 13-09-21
var jose = {
    nombre : "Jose",
    apellido : "Rusca",
    nombreCompleto: function(){
        return this.apellido + ", " + this.nombre;
    }
}
 var javier = Object.create(jose);

 javier.nombre = "Javier";
 javier.apellido = "Baez";
 Object.defineProperty(javier, "sueldo" , {
    enumerable: true,
    get: function() {
        return 130000;
    },
    writable: true, 
})
console.log(javier);