var javier = function (){
    var persona = {};

    persona.nombre = "Javier";
    persona.apellido = "Baez";
    persona.fechaNac = new Date();
    persona.nombreCompleto() = function(){
        return persona.apellido+" ,"+persona.nombre+" ,"+persona.fechaNac.toLocaleDateString();
    }
}

console.log(javier.nombreCompleto());
