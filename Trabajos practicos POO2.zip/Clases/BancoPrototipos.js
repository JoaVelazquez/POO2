// ---------------- DECLARACION DE PROTOTIPOS Y METODOS ------------------------------

function Cuenta(dni, nombre, apellido, saldoP){
    Cuenta,contador=++Cuenta.contador ||1;
    var dni = dni;
    this.nombre = nombre;
    this.apellido = apellido;
    this.saldoP = saldoP;
    this.getDni= function(){
        return dni;
    }
}

function CuentaE(dni, nombre, apellido, saldoP, saldoD, saldoE){
    Cuenta.call(this, dni, nombre, apellido, saldoP);
    this.saldoD = saldoD;
    this.saldoE = saldoE;
    
}

function CuentaVIP(dni,nombre,apellido,saldoP,saldoD,saldoE,montoPrestamo){
    CuentaE.call(this,dni, nombre, apellido, saldoP, saldoD, saldoE);
    this.montoPrestamo = montoPrestamo;
}



Cuenta.prototype.depositaP = function(monto){
    if(monto < 0){
        console.log("Monto invalido!");
    }else{
        this.saldoP = this.saldoP + monto;
    }
}

Cuenta.prototype.retiraP = function(monto){
    if(monto < 0){
        console.log("Monto invalido!");
    }else{
        this.saldoP = this.saldoP - monto;
    }
}

Cuenta.prototype.muestrate = function(){
    var mensaje = this.getDni()"CUENTA P\n" + this.nombre + " " + this.apellido + " tiene: \n> Pesos:" + this.saldoP;
    return mensaje;
}

CuentaE.prototype.depositaD = function(monto){
    if(monto<0){
        console.log("Monto invalido!");
    }else{
        this.saldoD = this.saldoD + monto;
    }
}

CuentaE.prototype.depositaE = function(monto){
    if(monto<0){
        console.log("Monto invalido!");
    }else{
        this.saldoE = this.saldoE + monto;
    }
}

CuentaE.prototype.retiraD = function(monto){
    if(monto < 0){
        console.log("Monto invalido!");
    }else{
        this.saldoD = this.saldoD - monto;
    }
}

CuentaE.prototype.retiraE = function(monto){
    if(monto < 0){
        console.log("Monto invalido!");
    }else{
        this.saldoE = this.saldoE - monto;
    }
}

CuentaE.prototype.muestrate = function(){
    var mensaje ="CUENTA E\n" + this.nombre + " " + this.apellido + " tiene: \n> Pesos:" + this.saldoP + "\n> Dolares:" + this.saldoD + "\n> Euros:" + this.saldoE + "\n";
    return mensaje;
} 

CuentaVIP.prototype.pedirPretsamo = function(){
    this.saldoP = this.saldoP+this.montoPrestamo;
}

CuentaVIP.prototype.muestrate = function(){
    var mensaje ="CUENTA VIP\n" + this.nombre + " " + this.apellido + " tiene: \n> Pesos:" + this.saldoP + "\n> Dolares:" + this.saldoD + "\n> Euros:" + this.saldoE + "\n> Monto Prestamo:" + this.montoPrestamo + "\n";
    return mensaje;
} 



CuentaE.prototype = Object.create(Cuenta.prototype);
Cuenta.prototype.constructor = Cuenta;

CuentaVIP.prototype = Object.create(CuentaE.prototype);
CuentaVIP.prototype.constructor = CuentaVIP;



// ----------------------- PROGRAMA DE PRUEBA ----------------------


var c1 = new Cuenta(39437182, "Joaquin", "Velazquez", 9800);

var ce1 = new CuentaE(1234567, "Agustin", "Massieri",750, 4500, 5460);

var cvip1 = new CuentaVIP(16798654, "Jose","Rusca",100000,4000,5600,4565);

console.log(c1.muestrate());
console.log(ce1.muestrate());
console.log(cvip1.muestrate());
/*
console.log("\n--Deposito dinero en ambas cuentas--");
c1.depositaP(805);
ce1.depositaP(987);

console.log("--Muestro las cuentas luego de haber depositado-- ");
console.log(c1.muestrate());
console.log(ce1.muestrate());


console.log("\n--Retiro dinero en ambas cuentas--");
c1.retiraP(805);
ce1.retiraP(987);

console.log("--Muestro las cuentas luego de haber retirado dinero-- ");
console.log(c1.muestrate());
console.log(ce1.muestrate());

console.log("\n--Deposito dolares y euros en la cuenta--");

ce1.depositaD(265);
ce1.depositaE(456);

console.log("--Muestro la cuenta luego de haber depositado dolares y euros-- ");

console.log(ce1.muestrate());
*/
console.log("--Muestro la cuenta VIP luego de haber depositado dolares y euros-- ");
cvip1.depositaP(5);
cvip1.depositaE(5);
cvip1.depositaD(5);
console.log(cvip1.muestrate());

console.log("--Muestro la cuenta VIP luego de haber retirado dolares y euros + pedido prestamo-- ");
cvip1.retiraP(7);
cvip1.retiraE(7);
cvip1.retiraD(7);
cvip1.pedirPretsamo();
console.log(cvip1.muestrate());