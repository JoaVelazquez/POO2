//prototipos -> objeto que actua como plantilla que hereda metodos y propiedades.
//Un obj prototipo del objeto puede tener a su vez otro objeto prototipo, el cual hereda metodos
//y propiedades y asi sucesivamente
//Esto es la cadena de prototipos.
//La heremcia prototipica es mas simple que la clasica. un objeto nuevo puede heredar de un o antiguo.
//PROTOTYPE permite identificar el objeto utilizado como prototipo. Se puede obtener y asignar por medio de
//dos metodos.
//No debemos confundir con la propiuedad prototype de las funciones(constructoras) que especifica el prototipo
//de los objetos que construyo.
// CREACION DE OBJETOS SIN CLASES--
/*

//Esto seria como creamos una persona con .js
class Persona {
    constructor(nombre, apellido, fechaNacimiento){
        this.nombre = nombre;
        this.apellido = apellido;
        this.fechaNacimiento = fechaNacimiento;
    }
    nombreCompleto( ){
        return this.apellido + ", " + this.nombre;
    }
}
var javier = new.Persona("Javier","Baez", new Date());
console.log(javier.nombreCompleto());
*/
//Aca es como seria con JSON :
var javier = {
    nombre : "Javier",
    apellido : "Baez",
    fechaNacimiento : new Date(1998, 6, 15),
    nombreCompleto: function(){
        return this.apellido + ", " + this.nombre + ", " + this.fechaNacimiento;
    }
}
var carlos = {
    nombre : "Carlos",
    apellido : "Martinez",
    fechaNacimiento : new Date(1999, 6, 7),
    nombreCompleto: function(){
        return this.apellido + ", " + this.nombre + ", " + this.fechaNacimiento.toLocaleDateString();
    }
}
var personas = [javier, carlos];
personas.forEach( item => console.log(item.nombreCompleto()));
