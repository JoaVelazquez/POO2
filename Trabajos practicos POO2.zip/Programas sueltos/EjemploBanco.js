class Cuenta {
    #dni;
    nombre;
    apellido;
    #saldoPesos = 0;

    constructor(dni,apellido,nombre){
        this.#dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
    }
    get dni(){
        return this.#dni;
    }
    get saldoPesos(){
        return this.#saldoPesos;
    }
    depositar(monto){
        if(monto>0){
            this.#saldoPesos+= monto;
        }else{
            console.log("Monto invalido!");
        }
    }
    retirar(monto){
        if(monto<0 && monto<this.#saldoPesos){
            this.#saldoPesos-=monto;
        }else{
            console.log("Saldo insuficiente.");
        }
    }
}

class CuentaE extends Cuenta{
    #saldoDolares;
    #saldoEuros;
    constructor(dni,apellido,nombre){
        super(dni,apellido,nombre)
        this.#saldoDolares=0;
        this.#saldoEuros=0;
    }
    get saldoDolares(){
        return this.#saldoDolares;
    }
    get saldoEuros(){
        return this.#saldoEuros;
    }
    depositarDolares(monto){
        if(monto<0){
            console.log("Monto invalido!");
        }else{
            this.#saldoDolares+=monto;
        }
    }
    depositarEuros(monto){
        if(monto<0){
            console.log("Monto invalido!");
        }else{
            this.#saldoEuros+=monto;
        }
    }
    retrirarDolares(monto){
        if(monto<this.#saldoDolares){
            console.log("Saldo insuficiente.");
        }else{

        }
    }
}
class CuentaVIP extends CuentaE{
    montoPrestamo;
    constructor(dni,apellido,nombre){
        super(dni,apellido,nombre);
        this.montoPrestamo=0;
    }
    set montoPrestamo(monto){
        if(monto<0){
            console.log("Monto invalido!");
        }else{
            this.montoPrestamo=monto;
        }
    }
}
class Sucursal{
    nombre;
    listaCuentas=[];
    constructor(nombre){
        this.nombre=nombre;
    }
    agregarCuenta(cuenta){
        this.listaCuentas.push(cuenta);
    }
    eliminarCuenta(dni){
        for(let i=0; i<this.listaCuentas.length; i++){
            if(this.listaCuentas[i].dni===dni){
                this.listaCuentas.splice(i, 1);
            }
        }
    }
    mostrarCuentas(){
        this.listaCuentas.forEach(cuenta =>{console.log("Nombre del titular: ",
            cuenta.nombre," ",cuenta.apellido)})
    }
    modificarCuentaMontoPrestamo(dni,monto){
        for(let i=0; i<this.listaCuentas.length ; i++){
            if(this.listaCuentas[i].dni===dni){
                this.listaCuentas[i].montoPrestamo=monto;
            }
        }
    }
}

var c=new Cuenta(39437187,"Velazquez","Joaquin");
console.log(c);
console.log("dni: "+c.dni);
/*
c.depositar(-10);
c.depositar(110);
console.log("Saldo actual: $"+c.saldoPesos);
c.retirar(1000);
c.retirar(93);
console.log("Saldo actual: $"+c.saldoPesos);
*/
var ce=new CuentaE(36456789,"Ottulich","Julian");
console.log(ce);
console.log("dni: "+ce.dni);
var cvip=new CuentaVIP(16321547,"Hetfield","James")
cvip.montoPrestamo= 124500000
console.log(cvip);
console.log("dni: "+cvip.dni);
console.log("Saldo Pesos(ARS):   $"+cvip.saldoPesos);
console.log("Saldo Dolares(USD): $"+cvip.saldoDolares);
console.log("Saldo Euros(EUR):   Є"+cvip.saldoEuros);

var s= new Sucursal("HSBC_Recoleta");
s.agregarCuenta(c);
s.agregarCuenta(ce);
s.agregarCuenta(cvip);
console.log(s);
console.log("***Eliminamos a tuli***");
s.eliminarCuenta(36456789);
console.log(s);

s.modificarCuentaMontoPrestamo(39437187,25000);
s.mostrarCuentas();