/*


Progra basada en prototipos.
Las clases de js. Son una mejora sintactica sobre la herencia basada en prototipos de JavaScript.
La sintaxis de las clases no introduce un nuevo modelo de herencia orientada a objetos en JavaScript.
Las clases de  js proveen una sintaxis mucho mas clara.
Traduce clases a prototipos. 
Definicion de una clase:
En los lenguajes basados en clases , las clases se definen de forma separada.

Class Persona{
	Constructor(nombre,apellido) {
		This.nombre = nombre;
		This.apellido = apellido;
	}
}
Let javy = new Persona ("Javier", "Baez");

-Como visualizar variables globales:
//ver codigo en arch Clase2.js

-Propiedades/metodos publicos y privados
En JS todos los campos(propiedades)son publicos.






function varlist() {
    return Object.getOwnPropertyNames(this);
}
valor = 200;
console.log(varlist());
*/
/*
class Persona {

    #dni; // el campo no puede ser accedido directamente
    static #total = 0;
    static claseNombre = "Soy una persona!";
    constructor(nombre,apellido,dni) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.#dni = dni;
        Persona.#total = Persona.#total +1;
    }
    nombreCompleto(){
        return this.apellido + ", " + this.nombre +"( "+ this.#dni+" )";
    }
    static obtenerNombreDeLaClase(){
        return "Soy una persona!";
    }
    totalPersonas(){
        return Persona.#total;
    }
}
let javy = new Persona ("Javier", "Baez", 39437187);
let clau = new Persona ("Claudio", "Lopez", 42456987);


console.log(Persona.obtenerNombreDeLaClase());
console.log(javy.nombreCompleto());
console.log(javy.totalPersonas());

console.log(Persona.obtenerNombreDeLaClase());
console.log(clau.nombreCompleto());
console.log(clau.totalPersonas());
*/
class Persona {

    #dni; // el campo no puede ser accedido directamente
    static #total = 0;
    static claseNombre = "Soy una persona!";
    constructor(nombre,apellido,dni, fechaNacimiento) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.#dni = dni;
        this.fechaNacimiento = this.fechaNacimiento;
        Persona.#total = Persona.#total +1;
    }
    totalPersonas(){
        return Persona.#total;
    }
    get edad(){
        return parseInt((new Date() - this.fechaNacimiento)/ 315360000000);
    }
    get nombreCompleto() {
        return this.apellido + ", " + this.nombre +"( "+ this.#dni+" )    edad: "+this.edad;
    }
    static obtenerNombreDeLaClase(){
        return "Soy una persona!";
    }

    set nombreCompleto(valor){
        var splitValue = valor.split(", ");
        this.apellido = splitValue[0];
        this.nombre = splitValue[1];
    }

}
var personas = [new Persona ("Javier", "Baez", new Date(1992 ,11 ,11 )),
new Persona ("Claudio", "Lopez", new Date(1999,11,30)),
new Persona ("Ana", "Garcia", new Date(2001,01,21))];


personas[0].nombreCompleto = "Joaquin, Velazquez";
/*
console.log(Persona.obtenerNombreDeLaClase());
console.log(javy.nombreCompleto());
console.log(javy.totalPersonas());

console.log(Persona.obtenerNombreDeLaClase());
console.log(clau.nombreCompleto());
console.log(clau.totalPersonas());
*/
personas.forEach( item => console.log(item.nombreCompleto));


