var valores = [ 1,56,25,3,4,6,6,9,25,25,1,6,39,25,25,25,1 ];
/*
var contactual= 0;
var contmax= 0;


for( i=0 ; i< nums.length ; i++){
    for( j=0 ; j<=nums.length ;j++){
        if (nums[i] == nums[j] )
            contactual++;
    }
    if( contactual>contmax){
        contmax = contactual;
        contactual = 0;
        numMax = nums[i][j];
    }
    j=0;
}
console.log("El numero mas repetido es el "+numMax+" y se repite"+contmax+" veces.");
*/
//CODIGO PROFE
//Usa reduce(), que ejecuta una funcion reductara sobre cada elemento
//del array, devolviendo como resultado un unico valor
console.log(obtenerValorMasRepetido(valores));

function obtenerValorMasRepetido(valores){

    return valores.reduce((anterior,actual) => {
        let cantAnterior = valores.filter(item => item===anterior).length;
        let cantActual = valores.filter(item => item===actual).length;
        console.log("anterior: "+ anterior);
        console.log("actual : "+ actual);
        console.log("---------------");
        if(cantAnterior > cantActual )
            return anterior;
        else
            return actual;
    })
}

valores.filter( item => item===25)
