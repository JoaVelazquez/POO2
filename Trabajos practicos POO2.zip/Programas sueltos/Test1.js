/*

Tipos de variables:

1. var -> Alcance a nivel de funcion
2. let -> Alcance a nivel de bloque
3. cons -> Alcance a nivel de bloque


//Ejemplo Var

function ejemploVar() {
	var var1 = 10;
	if(var1 === 10) { 	 
  	var var2 = 40;
  	console.log("var1: " + var1 );
  	console.log("var2: " + var2 );
	}
	console.log("var1: " + var1 );
	console.log("var2: " + var2 );
  }

    ejemploVar();


//Ejemplo Let

  function ejemploLet() {
	let let1 = 10;
	if(let1 === 10) { 	 
  	let let2 = 40;
  	console.log("let1: " + let1 );
  	console.log("var2: " + let2 );
	}
	console.log("let1: " + let1 );
	console.log("let2: " + let2 );
  }

  ejemploVar();

  

  //Funcion anonima

  var respuesta = function (nombre){
      console.log("Hola " + nombre + ", soy una funcion anonima!");
  }

  respuesta("Juan");

  

  //Funcion anonima - como parametro: Funcion Callback
  //OPCION 1:
  setTimeout(function(){
      console.log("Saudo en 1 segundo");
  }, 1000);

  ---------------------------------------------------
  //OPCION 2:
  var f = function (){
      console.log("Saludo en 1 segundo");
  }

  setTimeOut(f, 1000);


//De que nos sirve llamar una funcion en otra?(Callbacks)
//Recursion, o tambien para saber cuando una funcion termina

//Arrow Functions

() => {...instrucciones...}
        (a,b,c) =>{let res=a+b+c;
                    return res;}
        (a,b,c) =>a+b+c;
        a =>a+10;

//Clausuras (Closure)

function creaFun(){
    var nombre = "Progra objetos 2";
    function muestraNom() {
        console.log(nombre);
    }
    return muestraNom;
}
//Llamamos a la funcion
//var miFunc = creaFunc();
//miFunc();

//Sintaxis Spread - para pasar parametros
function sum(x,y,z){
    return x+y+z;
}
const numbers = [1, 2, 3];
console.log(sum(...numbers)); 

//los tres puntos practicamente accede a los valores del arreglo
//sin tener que recorrerlo

//Arreglos
//Como crearlos:
let frutas = ["Manzana","Banana"];
let frutas = new Array("Manzana","Banana");
let frutas = new Array(10);//En este caso es un arreglo sin items

const array1 = [1,2,45,6,23,55];

var f= function(valor{if(valor===1){console.log("Es un 1")}})
array1.forEach(
    element=> f(element)
);

//map - crea un array con los res de la llamada a la fun indicada 
//aplicada a todos sus elementos
//Aca un ejemplo que hace que cada elemento se multiplique por 2

var num = [1,2,45,6];
var dobles = num.map(function(x)
{
    return x * 2;
});

//Includes - determina si una matriz incluye un det elemento (binario)

const pets = ["cat","dog","bat"];
console.log(pets/includes("cat"));
//true

*/
