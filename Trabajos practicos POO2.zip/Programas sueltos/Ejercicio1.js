/*
Se tiene una muestra de ADN. Verificar si esta
muestra tiene una cadena de tipo "TTGG". Imprimir 
si se encuentra o no esta secuencia.
arr =  ["TTAATTGAAATGG"]


var adn = 'TTAATGGAAATGG';

res = adn.includes('TTGG');

if(res === true){
    console.log("Secuencia encontrada");
}else{
    console.log("Secuencia no encontrada");
}
//Funciona bien, ahora 1.2

Se tienen multiples muestras.
Solo se pueden analizar las muestras con mas de 
16 caracteres (de no ser asi, mostrar mje 
"muestra no analizable").
Si la muestra contiene la secuencia 'AATT' mostrar
el mje: el paciente tiene ojos azules
Si tiene 'GGAA' mostrar el mje:
el paciente tiene ojos azules.
si tiene 'RRGG' tiene ojos verdes.
*/
function verSecuencia( variable,secuencia){
    res = variable.includes(secuencia);
    return res;
}

var muestras = ['AATTXXXXXXXXXXXXXX',
                'GGAAXXXXXXXXXXXXXX',
                'RRGGXXXXXXXXXXXXXX',
                'GGTTGGTTGTAA'];

    muestras.forEach(element =>{
        if((element.length)>16){
            if(verSecuencia(element,'AATT')===true){
                console.log("El paciente tiene ojos azules");
            }if(verSecuencia(element,'GGAA')===true){
                console.log("El paciente tiene ojos marrones");
            }if(verSecuencia(element,'RRGG')===true){
                console.log("El paciente tiene ojos verdes")
            }
        }else{
            console.log("Muestra no analizable");
        }
    });